#include<bits/stdc++.h>
int decodefinal();