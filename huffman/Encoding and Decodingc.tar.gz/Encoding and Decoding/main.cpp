#include <bits/stdc++.h>
#include "huffman.h"
#include "string"
using namespace std;
int startcompressing()
{
  string g= "Sendingthisdataovercompression";
  string encoded=encoder(g);
  

}
